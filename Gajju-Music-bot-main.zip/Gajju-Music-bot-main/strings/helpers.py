HELP_1 = """<b><u>ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs :</u></b>

ᴊᴜsᴛ ᴀᴅᴅ <b>ᴄ</b> ᴀᴛ ᴛʜᴇ ʙᴇɢɪɴɴɪɴɢ ᴏғ ᴄᴏᴍᴍᴀɴᴅs ᴛᴏ ᴜsᴇ ᴛʜᴇᴍ ғᴏʀ ᴄʜᴀɴɴᴇʟs.

• /pause : ᴘᴀᴜsᴇs ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴘʟᴀʏɪɴɢ sᴛʀᴇᴀᴍ.  
• /resume : ʀᴇsᴜᴍᴇs ᴛʜᴇ ᴘᴀᴜsᴇᴅ sᴛʀᴇᴀᴍ.  
• /skip : sᴋɪᴘs ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴛʀᴀᴄᴋ ᴀɴᴅ sᴛᴀʀᴛs ᴛʜᴇ ɴᴇxᴛ ᴏɴᴇ.  
• /end ᴏʀ /stop : ᴄʟᴇᴀʀs ᴛʜᴇ ǫᴜᴇᴜᴇ ᴀɴᴅ sᴛᴏᴘs ᴛʜᴇ sᴛʀᴇᴀᴍ.  
• /player : ᴏᴘᴇɴs ᴀɴ ɪɴᴛᴇʀᴀᴄᴛɪᴠᴇ ᴘʟᴀʏᴇʀ ᴘᴀɴᴇʟ.  
• /queue : sʜᴏᴡs ᴛʜᴇ ǫᴜᴇᴜᴇᴅ ᴛʀᴀᴄᴋs.
"""

HELP_2 = """<b><u>ᴀᴜᴛʜ ᴜsᴇʀs :</u></b>

ᴀᴜᴛʜ ᴜsᴇʀs ᴄᴀɴ ᴜsᴇ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs ᴡɪᴛʜᴏᴜᴛ ʜᴀᴠɪɴɢ ᴀᴅᴍɪɴ ʀɪɢʜᴛs ɪɴ ᴛʜᴇ ᴄʜᴀᴛ.

• /auth [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ] : ᴀᴅᴅs ᴀ ᴜsᴇʀ ᴛᴏ ᴛʜᴇ ᴀᴜᴛʜ ʟɪsᴛ.  
• /unauth [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ] : ʀᴇᴍᴏᴠᴇs ᴀ ᴜsᴇʀ ғʀᴏᴍ ᴛʜᴇ ᴀᴜᴛʜ ʟɪsᴛ.  
• /authusers : sʜᴏᴡs ᴛʜᴇ ʟɪsᴛ ᴏғ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴜsᴇʀs.
"""

HELP_3 = """<b><u>ʙʀᴏᴀᴅᴄᴀsᴛ ғᴇᴀᴛᴜʀᴇ :</u></b> [sᴜᴅᴏ ᴏɴʟʏ]

• /broadcast [ᴍᴇssᴀɢᴇ/ʀᴇᴩʟʏ] : sᴇɴᴅs ᴀ ʙʀᴏᴀᴅᴄᴀsᴛ ᴛᴏ ᴀʟʟ sᴇʀᴠᴇᴅ ᴄʜᴀᴛs.

<b>ᴍᴏᴅᴇs :</b>  
- <b>-pin</b> : ᴘɪɴs ᴛʜᴇ ᴍᴇssᴀɢᴇ.  
- <b>-pinloud</b> : ᴘɪɴs ᴀɴᴅ sᴇɴᴅs ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴ.  
- <b>-user</b> : sᴇɴᴅs ᴛᴏ ᴜsᴇʀs ᴡʜᴏ sᴛᴀʀᴛᴇᴅ ᴛʜᴇ ʙᴏᴛ.  
- <b>-assistant</b> : sᴇɴᴅs ғʀᴏᴍ ᴛʜᴇ ᴀssɪsᴛᴀɴᴛ ᴀᴄᴄᴏᴜɴᴛ.  
- <b>-nobot</b> : ᴅɪsᴀʙʟᴇs ʙᴏᴛ sᴇɴᴅɪɴɢ.

<b>ᴇxᴀᴍᴩʟᴇ :</b>  
<code>/broadcast -user -assistant -pin ᴛᴇsᴛɪɴɢ ʙʀᴏᴀᴅᴄᴀsᴛ</code>
"""

HELP_4 = """<b><u>ᴄʜᴀᴛ ʙʟᴀᴄᴋʟɪsᴛ :</u></b> [sᴜᴅᴏ ᴏɴʟʏ]

ʀᴇsᴛʀɪᴄᴛ ᴀʙᴜsɪᴠᴇ ᴏʀ sᴘᴀᴍᴍʏ ᴄʜᴀᴛs ғʀᴏᴍ ᴜsɪɴɢ ᴛʜᴇ ʙᴏᴛ.

• /blacklistchat [ɪᴅ] : ʙʟᴀᴄᴋʟɪsᴛs ᴀ ᴄʜᴀᴛ.  
• /whitelistchat [ɪᴅ] : ʀᴇᴍᴏᴠᴇs ᴀ ᴄʜᴀᴛ ғʀᴏᴍ ʙʟᴀᴄᴋʟɪsᴛ.  
• /blacklistedchat : sʜᴏᴡs ᴀʟʟ ʙʟᴀᴄᴋʟɪsᴛᴇᴅ ᴄʜᴀᴛs.
"""

HELP_5 = """<b><u>ʙʟᴏᴄᴋ ᴜsᴇʀs :</u></b> [sᴜᴅᴏ ᴏɴʟʏ]

ʙʟᴏᴄᴋᴇᴅ ᴜsᴇʀs ᴄᴀɴ’ᴛ ᴜsᴇ ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅs.

• /block [ᴜsᴇʀ/ʀᴇᴩʟʏ] : ʙʟᴏᴄᴋs ᴀ ᴜsᴇʀ.  
• /unblock [ᴜsᴇʀ/ʀᴇᴩʟʏ] : ᴜɴʙʟᴏᴄᴋs ᴀ ᴜsᴇʀ.  
• /blockedusers : sʜᴏᴡs ᴀʟʟ ʙʟᴏᴄᴋᴇᴅ ᴜsᴇʀs.
"""

HELP_6 = """<b><u>ᴄʜᴀɴɴᴇʟ ᴘʟᴀʏ :</u></b>

sᴛʀᴇᴀᴍ ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ ɪɴ ᴀ ᴄʜᴀɴɴᴇʟ.

• /cplay : sᴛᴀʀᴛ ᴀᴜᴅɪᴏ sᴛʀᴇᴀᴍɪɴɢ.  
• /cvplay : sᴛᴀʀᴛ ᴠɪᴅᴇᴏ sᴛʀᴇᴀᴍɪɴɢ.  
• /cplayforce or /cvplayforce : ғᴏʀᴄᴇs ᴀ ɴᴇᴡ sᴛʀᴇᴀᴍ.  
• /channelplay [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ] ᴏʀ [disable] : ʟɪɴᴋs ᴀ ᴄʜᴀɴɴᴇʟ ᴡɪᴛʜ ᴀ ɢʀᴏᴜᴩ.
"""

HELP_7 = """<b><u>ɢʟᴏʙᴀʟ ʙᴀɴ :</u></b> [sᴜᴅᴏ ᴏɴʟʏ]

• /gban [ᴜsᴇʀ/ʀᴇᴩʟʏ] : ɢʟᴏʙᴀʟʟʏ ʙᴀɴs ᴀ ᴜsᴇʀ.  
• /ungban [ᴜsᴇʀ/ʀᴇᴩʟʏ] : ᴜɴʙᴀɴs ᴀ ɢʟᴏʙᴀʟʟʏ ʙᴀɴɴᴇᴅ ᴜsᴇʀ.  
• /gbannedusers : sʜᴏᴡs ᴛʜᴇ ʟɪsᴛ ᴏғ ɢʟᴏʙᴀʟʟʏ ʙᴀɴɴᴇᴅ ᴜsᴇʀs.
"""

HELP_8 = """<b><u>ʟᴏᴏᴘ sᴛʀᴇᴀᴍ :</u></b>

ʀᴇᴘᴇᴀᴛ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ sᴛʀᴇᴀᴍ.

• /loop [enable/disable] : ᴇɴᴀʙʟᴇs ᴏʀ ᴅɪsᴀʙʟᴇs ʟᴏᴏᴘ.  
• /loop [1–10] : sᴇᴛs ʟᴏᴏᴘ ᴄᴏᴜɴᴛ.
"""

HELP_9 = """<b><u>ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ :</u></b> [sᴜᴅᴏ ᴏɴʟʏ]

• /logs : ɢᴇᴛs ʙᴏᴛ ʟᴏɢs.  
• /logger [enable/disable] : ᴛᴏɢɢʟᴇs ᴀᴄᴛɪᴠɪᴛʏ ʟᴏɢɢɪɴɢ.  
• /maintenance [enable/disable] : ᴇɴᴀʙʟᴇs ᴏʀ ᴅɪsᴀʙʟᴇs ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ.
"""

HELP_10 = """<b><u>ᴘɪɴɢ & sᴛᴀᴛs :</u></b>

• /start : sᴛᴀʀᴛs ᴛʜᴇ ʙᴏᴛ.  
• /help : sʜᴏᴡs ᴛʜᴇ ʜᴇʟᴩ ᴍᴇɴᴜ.  
• /ping : sʜᴏᴡs ʙᴏᴛ ʟᴀᴛᴇɴᴄʏ ᴀɴᴅ sʏsᴛᴇᴍ sᴛᴀᴛs.  
• /stats : sʜᴏᴡs ᴏᴠᴇʀᴀʟʟ ʙᴏᴛ sᴛᴀᴛɪsᴛɪᴄs.
"""

HELP_11 = """<b><u>ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅs :</u></b>

<b>v :</b> ᴠɪᴅᴇᴏ ᴘʟᴀʏ  
<b>force :</b> ғᴏʀᴄᴇ ᴘʟᴀʏ  

• /play or /vplay : sᴛᴀʀᴛs ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ sᴛʀᴇᴀᴍɪɴɢ.  
• /playforce or /vplayforce : ғᴏʀᴄᴇs ᴀ ɴᴇᴡ sᴛʀᴇᴀᴍ.
"""

HELP_12 = """<b><u>sʜᴜғғʟᴇ ǫᴜᴇᴜᴇ :</u></b>

• /shuffle : sʜᴜғғʟᴇs ᴛʜᴇ ǫᴜᴇᴜᴇ.  
• /queue : sʜᴏᴡs ᴛʜᴇ sʜᴜғғʟᴇᴅ ǫᴜᴇᴜᴇ.
"""

HELP_13 = """<b><u>sᴇᴇᴋ sᴛʀᴇᴀᴍ :</u></b>

• /seek [sᴇᴄᴏɴᴅs] : ɢᴏᴇs ғᴏʀᴡᴀʀᴅ ɪɴ ᴛʜᴇ sᴛʀᴇᴀᴍ.  
• /seekback [sᴇᴄᴏɴᴅs] : sᴇᴇᴋs ʙᴀᴄᴋᴡᴀʀᴅ.
"""

HELP_14 = """<b><u>sᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅ :</u></b>

• /song [ɴᴀᴍᴇ/ʏᴛ ᴜʀʟ] : ᴅᴏᴡɴʟᴏᴀᴅs ᴀ sᴏɴɢ ɪɴ ᴍᴘ3 ᴏʀ ᴍᴘ4 ғᴏʀᴍᴀᴛ.
"""

HELP_15 = """<b><u>sᴘᴇᴇᴅ ᴄᴏᴍᴍᴀɴᴅs :</u></b> [ᴀᴅᴍɪɴ ᴏɴʟʏ]

ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴘʟᴀʏʙᴀᴄᴋ sᴘᴇᴇᴅ ᴏғ ᴛʜᴇ sᴛʀᴇᴀᴍ.

• /speed or /playback : ᴀᴅᴊᴜsᴛs ᴀᴜᴅɪᴏ sᴘᴇᴇᴅ ɪɴ ɢʀᴏᴜᴩs.  
• /cspeed or /cplayback : ᴀᴅᴊᴜsᴛs ᴀᴜᴅɪᴏ sᴘᴇᴇᴅ ɪɴ ᴄʜᴀɴɴᴇʟs.
"""

HELP_16 = """<b><u>𝐂ʜ𝛂ɴɢє 𝐋𝛂ɴɢυ𝛂ɢє :</u></b>

• /lang : 𝐂ʜ𝛂ɴɢє 𝐓ʜє 𝐁σᴛ 𝐋𝛂ɴɢυ𝛂ɢє 𝐓σ 𝐘συʀ 𝐏ʀєғєʀʀєᴅ 𝐋𝛂ɴɢυ𝛂ɢє ғσʀ 𝐀 𝐌σʀє 𝐏єʀѕσɴ𝛂ℓɪzєᴅ 𝐄xρєʀɪєɴᴄє.
"""

HELP_17 = """<b><u>ᴄʜᴀᴛʙᴏᴛ :</u></b>

A simple auto-reply chatbot that learns from your group, powered entirely by MongoDB. No external AI API is used.

• <code>/chatbot on</code> — enable auto-replies in this chat
• <code>/chatbot off</code> — disable auto-replies in this chat
"""
